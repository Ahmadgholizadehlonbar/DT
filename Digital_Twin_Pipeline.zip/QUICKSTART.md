# Quick Start Guide: Digital Twin Creation

**Goal:** Create a 3D building digital twin in 2 hours

---

## Prerequisites

```bash
# Install Python packages
pip install numpy python-pptx

# Ensure you have:
# - MATLAB with Image Processing Toolbox
# - ArcGIS Online account
# - Building photos
# - GPS coordinates
```

---

## 5-Minute Setup

1. **Get Building GPS Coordinates**
   ```
   - Open Google Maps
   - Right-click on building center
   - Copy coordinates (e.g., 33.773687, -84.395185)
   - Note ground elevation (use Google Earth)
   ```

2. **Measure Building Dimensions**
   ```
   - Width (East-West): ___ meters
   - Length (North-South): ___ meters
   - Height: ___ meters
   ```

3. **Capture Photos**
   ```
   - Take 20-30 photos per building side
   - Ensure 60-80% overlap between photos
   - Include all 4 facades + roof if possible
   ```

---

## 30-Minute Processing

### Option A: From MATLAB Data (You have .mat files)

```bash
# 1. Edit GPS coordinates in script
nano create_initial_geojson.py
# Update GPS_CENTER = {'latitude': XX.XXX, 'longitude': -XX.XXX, ...}

# 2. Run conversion
python3 create_initial_geojson.py

# 3. Upload to ArcGIS and check location
# If location correct, proceed to Step 2
```

### Option B: From Scratch (You have images only)

```bash
# 1. Run MATLAB processing
matlab -batch "run('matlab_processing.m')"

# 2. Convert to GeoJSON
python3 create_initial_geojson.py

# 3. Initial upload to ArcGIS
# Upload Complete.geojson and verify location
```

---

## 30-Minute Facade Correction

```bash
# 1. Test rotations for Facade 1
python3 rotate_facade1_multiple.py

# 2. Upload all Facade1_Rot*.geojson to ArcGIS
# Visually inspect which looks flattest

# 3. Pick best rotation (e.g., 3.0°)
cp facade_Final/Facade1_Rot3.0deg.geojson facade_Final/Facade1_Final.geojson

# 4. Repeat for other facades
python3 rotate_facade3_4_Y_axis.py
# Test, pick best, rename to *_Final.geojson

# 5. Process thermal anomalies
python3 create_thermal_red_blue_separate.py
```

---

## 15-Minute Final Assembly

```bash
# 1. Combine all components
python3 create_complete_final_building.py

# Output: DM_Smith_Building_COMPLETE_FINAL.geojson

# 2. Verify file
ls -lh facade_Final/*.geojson
```

---

## 15-Minute ArcGIS Upload

1. **Login to ArcGIS Online:** https://www.arcgis.com

2. **Upload:**
   - Content → Add Item → From Computer
   - Select: `DM_Smith_Building_COMPLETE_FINAL.geojson`
   - Set title and tags

3. **Open in Scene Viewer:**
   - Click "Open in Scene Viewer"

4. **Configure (CRITICAL):**
   ```
   Layer Properties → Elevation
   - Mode: "At an absolute height"
   - Elevation from: "elevation_m"
   ```

5. **Style:**
   ```
   Styles → Types (Unique symbols) → Field: "type"
   - ground → Gray
   - roof → Dark gray
   - facade → Blue
   - opening → Red (50% transparent)
   - thermal_anomaly → Orange/Cyan
   ```

6. **Done!** Share and explore your digital twin

---

## Common Issues (1-Minute Fixes)

### Building in wrong location?
```python
# Fix GPS coordinates in create_initial_geojson.py
GPS_CENTER = {
    'latitude': YOUR_LAT,   # Check sign!
    'longitude': YOUR_LON,  # Negative for West
    'altitude': YOUR_ALT
}
```

### Facades not flat?
```bash
# Test more angles
ROTATION_ANGLES = [0, 0.5, 1.0, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0]
```

### Building appears 2D?
```
ArcGIS: Layer → Elevation Mode → "At an absolute height"
Field: "elevation_m"
```

### Thermal not showing?
```bash
# Run separation script
python3 create_thermal_red_blue_separate.py

# Style with bright colors (orange/cyan)
```

---

## File Checklist

**Must Have:**
- [ ] `Complete.geojson` - Initial building
- [ ] `Facade*_Final.geojson` - Corrected facades (4 files)
- [ ] `Complete_Thermal_*.geojson` - Thermal layers (2 files)
- [ ] `DM_Smith_Building_COMPLETE_FINAL.geojson` - Final output ✓

**Nice to Have:**
- [ ] `README.md` - Full documentation
- [ ] `Digital_Twin_Creation_Workflow.pptx` - Presentation
- [ ] `processing_log.txt` - Your notes

---

## Success Criteria

✓ Building appears at correct GPS location
✓ All 4 facades visible
✓ Windows properly aligned
✓ Building dimensions within ±1m of targets
✓ Thermal anomalies visible
✓ 3D elevation working (not flat)

---

## Next Steps

1. **Add more buildings** - Repeat process for campus
2. **Integrate sensors** - Connect IoT data
3. **Time series** - Track changes over seasons
4. **Analysis** - Run energy simulations

---

## Need Help?

- **Full Documentation:** README.md (40 KB, complete guide)
- **Troubleshooting:** README.md → Section 8
- **Scripts:** All in `/scripts/` folder
- **Presentation:** Digital_Twin_Creation_Workflow.pptx

---

## Minimal Working Example

```bash
# Complete pipeline in 5 commands:

python3 create_initial_geojson.py
python3 rotate_facade1_multiple.py
# → Pick best, rename to Facade1_Final.geojson
python3 create_complete_final_building.py
# → Upload DM_Smith_Building_COMPLETE_FINAL.geojson to ArcGIS
```

**Time:** 30 minutes (excluding MATLAB processing)

---

**That's it!** You now have a 3D digital twin.
