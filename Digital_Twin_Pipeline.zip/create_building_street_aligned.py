#!/usr/bin/env python3
"""
Create Building with Street-Aligned Adjustments
- Rotate Facade1 around Cherry Street axis (0.5 degrees)
- Extend building along Cherry Street towards Bobby Dodd Street
"""

import json
import copy
import math
import numpy as np

print("="*80)
print("CREATING BUILDING WITH STREET-ALIGNED ADJUSTMENTS")
print("="*80)

INPUT_FOLDER = "facade_Final"
OUTPUT_FOLDER = "facade_Final"

# Parameters
FACADE1_ROTATION_DEGREES = 0.5  # Rotation around Cherry Street axis
EXTEND_TOWARDS_BOBBY_DODD = 1.0  # meters

print(f"\nAdjustments:")
print(f"  Facade1: {FACADE1_ROTATION_DEGREES}° rotation around Cherry Street axis")
print(f"  Extend: {EXTEND_TOWARDS_BOBBY_DODD}m towards Bobby Dodd Street")

# Files to load
facade_files = {
    'ground': 'Complete_Ground.geojson',
    'roof': 'Complete_Roof.geojson',
    'facade1': 'Facade1_Final.geojson',
    'facade2': 'Complete_Facade2_Rot0.5deg.geojson',
    'facade3': 'Complete_Facade3_Back_RotY0.5deg.geojson',
    'facade4': 'Complete_Facade4_Side_RotY1.5deg.geojson',
    'thermal_blue': 'Complete_Thermal_Blue_RotY0.5deg.geojson'
}

# Constants
LAT_CENTER = 33.773687
METERS_PER_DEGREE_LAT = 111000.0
METERS_PER_DEGREE_LON = 111000.0 * math.cos(math.radians(LAT_CENTER))

# Load each file
print("\nLoading files...")
loaded_data = {}

for name, filename in facade_files.items():
    try:
        filepath = f"{INPUT_FOLDER}/{filename}"
        with open(filepath, 'r') as f:
            data = json.load(f)
        loaded_data[name] = data
        print(f"  {name}: {len(data['features'])} features")
    except Exception as e:
        print(f"  ERROR loading {filename}: {e}")
        loaded_data[name] = None

# Calculate Facade1 center for rotation
print("\n" + "="*80)
print("STEP 1: Analyze Facade1 Orientation")
print("="*80)

facade1_data = loaded_data['facade1']
if facade1_data:
    facade1_coords = []
    for feature in facade1_data['features']:
        coords = feature['geometry']['coordinates']
        if isinstance(coords, list) and len(coords) > 0:
            coord_array = coords[0] if isinstance(coords[0], list) else coords
            for c in coord_array:
                if isinstance(c, list) and len(c) == 3:
                    facade1_coords.append(c)

    facade1_center_lon = sum(c[0] for c in facade1_coords) / len(facade1_coords)
    facade1_center_lat = sum(c[1] for c in facade1_coords) / len(facade1_coords)
    facade1_center_alt = sum(c[2] for c in facade1_coords) / len(facade1_coords)

    print(f"Facade1 center: [{facade1_center_lon:.10f}, {facade1_center_lat:.10f}, {facade1_center_alt:.2f}]")

    # Get facade1 wall (first feature)
    facade1_wall = facade1_data['features'][0]['geometry']['coordinates'][0]
    facade1_corners = [c for c in facade1_wall[:4] if isinstance(c, list) and len(c) == 3]

    # Calculate facade orientation (direction along the facade)
    # Assume bottom edge defines the street direction
    corner1 = np.array(facade1_corners[0])
    corner2 = np.array(facade1_corners[1])

    # Convert to ENU for calculation
    e1 = (corner1[0] - facade1_center_lon) * METERS_PER_DEGREE_LON
    n1 = (corner1[1] - facade1_center_lat) * METERS_PER_DEGREE_LAT
    e2 = (corner2[0] - facade1_center_lon) * METERS_PER_DEGREE_LON
    n2 = (corner2[1] - facade1_center_lat) * METERS_PER_DEGREE_LAT

    # Facade direction vector (along the street)
    facade_direction = np.array([e2 - e1, n2 - n1, 0])
    facade_direction_norm = facade_direction / np.linalg.norm(facade_direction)

    print(f"Facade1 direction (normalized): [{facade_direction_norm[0]:.4f}, {facade_direction_norm[1]:.4f}, 0]")

    # Create rotation axis: perpendicular to facade, in horizontal plane
    # This is the "Cherry Street axis" - the line along the street
    rotation_axis = facade_direction_norm

    print(f"Rotation axis (Cherry Street): [{rotation_axis[0]:.4f}, {rotation_axis[1]:.4f}, {rotation_axis[2]:.4f}]")

    # Create rotation matrix using Rodrigues' rotation formula
    rotation_angle_rad = math.radians(FACADE1_ROTATION_DEGREES)

    # Rodrigues' rotation formula
    K = np.array([
        [0, -rotation_axis[2], rotation_axis[1]],
        [rotation_axis[2], 0, -rotation_axis[0]],
        [-rotation_axis[1], rotation_axis[0], 0]
    ])

    R_facade1 = np.eye(3) + np.sin(rotation_angle_rad) * K + (1 - np.cos(rotation_angle_rad)) * (K @ K)

    print(f"\nFacade1 rotation matrix ({FACADE1_ROTATION_DEGREES}° around Cherry Street):")
    print(R_facade1)

# Step 2: Apply transformations
print("\n" + "="*80)
print("STEP 2: Apply Transformations")
print("="*80)

def transform_facade1(data, center_lon, center_lat, center_alt, rotation_matrix):
    """Apply rotation to Facade1"""
    transformed = copy.deepcopy(data)

    def gps_to_enu(lon, lat, alt):
        east = (lon - center_lon) * METERS_PER_DEGREE_LON
        north = (lat - center_lat) * METERS_PER_DEGREE_LAT
        up = alt - center_alt
        return np.array([east, north, up])

    def enu_to_gps(east, north, up):
        lon = center_lon + (east / METERS_PER_DEGREE_LON)
        lat = center_lat + (north / METERS_PER_DEGREE_LAT)
        alt = center_alt + up
        return [lon, lat, alt]

    for feature in transformed['features']:
        coords = feature['geometry']['coordinates']
        if not isinstance(coords, list) or len(coords) == 0:
            continue

        coord_array = coords[0] if isinstance(coords[0], list) else coords
        new_coords = []

        for c in coord_array:
            if isinstance(c, list) and len(c) == 3:
                # Convert to ENU
                enu = gps_to_enu(c[0], c[1], c[2])

                # Apply rotation around center
                rotated = rotation_matrix @ enu

                # Convert back
                new_gps = enu_to_gps(rotated[0], rotated[1], rotated[2])
                new_coords.append(new_gps)
            else:
                new_coords.append(c)

        feature['geometry']['coordinates'] = [new_coords]

        # Update elevation_m
        if 'elevation_m' in feature['properties']:
            valid = [c for c in new_coords if isinstance(c, list) and len(c) == 3]
            if valid:
                feature['properties']['elevation_m'] = sum(c[2] for c in valid) / len(valid)

    return transformed

# Transform Facade1
if loaded_data['facade1']:
    print("Transforming Facade1...")
    loaded_data['facade1'] = transform_facade1(
        loaded_data['facade1'],
        facade1_center_lon,
        facade1_center_lat,
        facade1_center_alt,
        R_facade1
    )
    print(f"  ✓ Facade1 rotated {FACADE1_ROTATION_DEGREES}° around Cherry Street axis")

# Step 3: Extend building towards Bobby Dodd Street
print("\n" + "="*80)
print("STEP 3: Extend Towards Bobby Dodd Street")
print("="*80)

# Bobby Dodd is to the west, so extend in the -E (west) direction
extension_vector = np.array([-EXTEND_TOWARDS_BOBBY_DODD, 0, 0])  # West
print(f"Extension: {EXTEND_TOWARDS_BOBBY_DODD}m west (towards Bobby Dodd)")

# Combine all features with extension
combined_features = []
overall_center_coords = []

# First, collect all coordinates to find overall center
for name, data in loaded_data.items():
    if data:
        for feature in data['features']:
            coords = feature['geometry']['coordinates']
            if isinstance(coords, list) and len(coords) > 0:
                coord_array = coords[0] if isinstance(coords[0], list) else coords
                for c in coord_array:
                    if isinstance(c, list) and len(c) == 3:
                        overall_center_coords.append(c)

overall_center_lon = sum(c[0] for c in overall_center_coords) / len(overall_center_coords)
overall_center_lat = sum(c[1] for c in overall_center_coords) / len(overall_center_coords)
overall_center_alt = sum(c[2] for c in overall_center_coords) / len(overall_center_coords)

print(f"Overall building center: [{overall_center_lon:.10f}, {overall_center_lat:.10f}, {overall_center_alt:.2f}]")

# Apply extension to all components
def apply_extension(data, extension_enu, center_lon, center_lat, center_alt):
    """Apply extension shift to data"""
    transformed = copy.deepcopy(data)

    for feature in transformed['features']:
        coords = feature['geometry']['coordinates']
        if not isinstance(coords, list) or len(coords) == 0:
            continue

        coord_array = coords[0] if isinstance(coords[0], list) else coords
        new_coords = []

        for c in coord_array:
            if isinstance(c, list) and len(c) == 3:
                # Convert to ENU
                e = (c[0] - center_lon) * METERS_PER_DEGREE_LON
                n = (c[1] - center_lat) * METERS_PER_DEGREE_LAT
                u = c[2] - center_alt

                # Apply extension
                e += extension_enu[0]
                n += extension_enu[1]
                u += extension_enu[2]

                # Convert back
                lon = center_lon + (e / METERS_PER_DEGREE_LON)
                lat = center_lat + (n / METERS_PER_DEGREE_LAT)
                alt = center_alt + u

                new_coords.append([lon, lat, alt])
            else:
                new_coords.append(c)

        feature['geometry']['coordinates'] = [new_coords]

    return transformed

for name, data in loaded_data.items():
    if data:
        extended_data = apply_extension(data, extension_vector, overall_center_lon, overall_center_lat, overall_center_alt)
        combined_features.extend(extended_data['features'])

print(f"Total features: {len(combined_features)}")

# Step 4: Create final building
print("\n" + "="*80)
print("STEP 4: Create Final Building")
print("="*80)

final_building = {
    "type": "FeatureCollection",
    "name": "Complete_Building_Street_Aligned",
    "crs": {
        "type": "name",
        "properties": {"name": "urn:ogc:def:crs:OGC:1.3:CRS84"}
    },
    "features": combined_features
}

# Verify dimensions
verify_coords = []
for f in final_building['features']:
    coords = f['geometry']['coordinates'][0]
    for c in coords:
        if isinstance(c, list) and len(c) == 3:
            verify_coords.append(c)

lons = [c[0] for c in verify_coords]
lats = [c[1] for c in verify_coords]
alts = [c[2] for c in verify_coords]

width = (max(lons) - min(lons)) * METERS_PER_DEGREE_LON
length = (max(lats) - min(lats)) * METERS_PER_DEGREE_LAT
height = max(alts) - min(alts)

print(f"Final dimensions:")
print(f"  Width: {width:.2f}m")
print(f"  Length: {length:.2f}m")
print(f"  Height: {height:.2f}m")
print(f"  Features: {len(final_building['features'])}")

# Save
output_file = f"{OUTPUT_FOLDER}/Complete_Building_Street_Aligned.geojson"
with open(output_file, 'w') as f:
    json.dump(final_building, f, indent=2)

file_size = len(json.dumps(final_building)) / 1024

print("\n" + "="*80)
print("✓✓✓ STREET-ALIGNED BUILDING CREATED ✓✓✓")
print("="*80)
print(f"\nFile: {output_file} ({file_size:.1f} KB)")
print(f"\nAdjustments applied:")
print(f"  ✓ Facade1: {FACADE1_ROTATION_DEGREES}° rotation around Cherry Street axis")
print(f"  ✓ Extended {EXTEND_TOWARDS_BOBBY_DODD}m west towards Bobby Dodd Street")
print(f"  ✓ All facades with their correct rotations preserved")
print(f"  ✓ {len(final_building['features'])} total features")
print("\nUPLOAD: Complete_Building_Street_Aligned.geojson")
print("="*80)
