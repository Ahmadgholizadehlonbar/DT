#!/usr/bin/env python3
"""
Create Complete Final Building
Combine all correctly rotated components into one complete building file
"""

import json
import copy

print("="*80)
print("CREATING COMPLETE FINAL BUILDING")
print("="*80)

INPUT_FOLDER = "facade_Final"
OUTPUT_FOLDER = "facade_Final"

# All component files with their correct rotations
component_files = {
    'ground': {
        'file': 'Complete_Ground.geojson',
        'description': 'Ground plane'
    },
    'roof': {
        'file': 'Complete_Roof.geojson',
        'description': 'Roof plane'
    },
    'facade1': {
        'file': 'Facade1_Final.geojson',
        'description': 'Facade 1 with 32 windows (final rotation)'
    },
    'facade2': {
        'file': 'Complete_Facade2_Rot0.5deg.geojson',
        'description': 'Facade 2 with 32 windows (0.5° X-axis)'
    },
    'facade3': {
        'file': 'Complete_Facade3_Back_RotY0.5deg.geojson',
        'description': 'Facade 3 (Back) with 20 windows (0.5° Y-axis)'
    },
    'facade4': {
        'file': 'Complete_Facade4_Side_RotY1.5deg.geojson',
        'description': 'Facade 4 (Side) with 25 windows (1.5° Y-axis)'
    },
    'thermal_blue': {
        'file': 'Complete_Thermal_Blue_RotY0.5deg.geojson',
        'description': '42 Blue thermal anomalies (0.5° Y-axis)'
    }
}

# Try to load red thermal if available
try:
    import os
    if os.path.exists(f"{INPUT_FOLDER}/Complete_Thermal_Red_RotX0.5deg.geojson"):
        component_files['thermal_red'] = {
            'file': 'Complete_Thermal_Red_RotX0.5deg.geojson',
            'description': '5 Red thermal anomalies (0.5° X-axis)'
        }
except:
    pass

print(f"\nComponents to include:")
for name, info in component_files.items():
    print(f"  - {name}: {info['description']}")

# Load all components
print("\n" + "="*80)
print("LOADING COMPONENTS")
print("="*80)

all_features = []
component_counts = {}
successful_loads = 0
failed_loads = 0

for name, info in component_files.items():
    try:
        filepath = f"{INPUT_FOLDER}/{info['file']}"
        with open(filepath, 'r') as f:
            data = json.load(f)

        feature_count = len(data['features'])
        component_counts[name] = feature_count

        # Add all features
        all_features.extend(data['features'])

        print(f"✓ {name}: {feature_count} features from {info['file']}")
        successful_loads += 1

    except Exception as e:
        print(f"✗ {name}: Failed to load - {e}")
        component_counts[name] = 0
        failed_loads += 1

print(f"\nLoading summary:")
print(f"  Successful: {successful_loads}")
print(f"  Failed: {failed_loads}")
print(f"  Total features: {len(all_features)}")

# Create complete building structure
print("\n" + "="*80)
print("CREATING COMPLETE BUILDING")
print("="*80)

complete_building = {
    "type": "FeatureCollection",
    "name": "DM_Smith_Building_Complete_Final",
    "crs": {
        "type": "name",
        "properties": {
            "name": "urn:ogc:def:crs:OGC:1.3:CRS84"
        }
    },
    "properties": {
        "building_name": "D.M. Smith Building",
        "location": "Georgia Institute of Technology",
        "total_features": len(all_features),
        "components": {
            "ground": component_counts.get('ground', 0),
            "roof": component_counts.get('roof', 0),
            "facade1": component_counts.get('facade1', 0),
            "facade2": component_counts.get('facade2', 0),
            "facade3": component_counts.get('facade3', 0),
            "facade4": component_counts.get('facade4', 0),
            "thermal_blue": component_counts.get('thermal_blue', 0),
            "thermal_red": component_counts.get('thermal_red', 0)
        },
        "rotations_applied": {
            "facade1": "3.0° X-axis (Cherry Street aligned)",
            "facade2": "0.5° X-axis",
            "facade3": "0.5° Y-axis",
            "facade4": "1.5° Y-axis",
            "thermal_blue": "0.5° Y-axis",
            "thermal_red": "0.5° X-axis"
        },
        "dimensions": {
            "target_width_m": 30.5,
            "target_length_m": 32.0,
            "target_height_m": 17.0
        }
    },
    "features": all_features
}

# Calculate actual dimensions
print("\nCalculating building dimensions...")
all_coords = []
for feature in all_features:
    coords = feature['geometry']['coordinates']
    if isinstance(coords, list) and len(coords) > 0:
        coord_array = coords[0] if isinstance(coords[0], list) else coords
        for c in coord_array:
            if isinstance(c, list) and len(c) == 3 and isinstance(c[0], (int, float)):
                all_coords.append(c)

if all_coords:
    import math
    LAT_CENTER = 33.773687
    METERS_PER_DEGREE_LAT = 111000.0
    METERS_PER_DEGREE_LON = 111000.0 * math.cos(math.radians(LAT_CENTER))

    lons = [c[0] for c in all_coords]
    lats = [c[1] for c in all_coords]
    alts = [c[2] for c in all_coords]

    width_m = (max(lons) - min(lons)) * METERS_PER_DEGREE_LON
    length_m = (max(lats) - min(lats)) * METERS_PER_DEGREE_LAT
    height_m = max(alts) - min(alts)

    center_lon = (max(lons) + min(lons)) / 2
    center_lat = (max(lats) + min(lats)) / 2
    center_alt = (max(alts) + min(alts)) / 2

    print(f"Actual dimensions:")
    print(f"  Width (E-W): {width_m:.2f}m")
    print(f"  Length (N-S): {length_m:.2f}m")
    print(f"  Height: {height_m:.2f}m")
    print(f"\nBuilding center:")
    print(f"  GPS: [{center_lon:.10f}, {center_lat:.10f}, {center_alt:.2f}]")
    print(f"\nElevation range:")
    print(f"  Ground: {min(alts):.2f}m")
    print(f"  Roof: {max(alts):.2f}m")

    # Update properties with actual values
    complete_building['properties']['actual_dimensions'] = {
        "width_m": round(width_m, 2),
        "length_m": round(length_m, 2),
        "height_m": round(height_m, 2)
    }
    complete_building['properties']['center'] = {
        "longitude": center_lon,
        "latitude": center_lat,
        "altitude_m": center_alt
    }

# Save complete building
output_file = f"{OUTPUT_FOLDER}/DM_Smith_Building_COMPLETE_FINAL.geojson"

print("\n" + "="*80)
print("SAVING COMPLETE BUILDING")
print("="*80)

with open(output_file, 'w') as f:
    json.dump(complete_building, f, indent=2)

file_size = len(json.dumps(complete_building)) / 1024

print(f"\n✓ Saved: {output_file}")
print(f"  File size: {file_size:.1f} KB")

# Feature breakdown
print("\n" + "="*80)
print("FEATURE BREAKDOWN")
print("="*80)

feature_types = {}
for feature in all_features:
    ftype = feature['properties'].get('type', 'unknown')
    if ftype not in feature_types:
        feature_types[ftype] = 0
    feature_types[ftype] += 1

print("\nFeatures by type:")
for ftype, count in sorted(feature_types.items()):
    print(f"  {ftype}: {count}")

print(f"\nTotal features: {len(all_features)}")

# Summary
print("\n" + "="*80)
print("✓✓✓ COMPLETE BUILDING CREATED ✓✓✓")
print("="*80)

print(f"""
FILE: {output_file}
SIZE: {file_size:.1f} KB

BUILDING COMPONENTS:
  ✓ Ground plane: {component_counts.get('ground', 0)} feature
  ✓ Roof plane: {component_counts.get('roof', 0)} feature
  ✓ Facade 1: {component_counts.get('facade1', 0)} features (front)
  ✓ Facade 2: {component_counts.get('facade2', 0)} features (front)
  ✓ Facade 3: {component_counts.get('facade3', 0)} features (back)
  ✓ Facade 4: {component_counts.get('facade4', 0)} features (side)
  ✓ Blue thermal: {component_counts.get('thermal_blue', 0)} features
  ✓ Red thermal: {component_counts.get('thermal_red', 0)} features

TOTAL: {len(all_features)} features

UPLOAD TO ARCGIS ONLINE:
  1. Upload as SINGLE LAYER: DM_Smith_Building_COMPLETE_FINAL.geojson
  2. Set elevation mode: "At an absolute height"
  3. Use elevation from: "elevation_m" attribute
  4. Style by feature type:
     - Ground: Gray
     - Roof: Dark gray
     - Facades: Blue (different shades)
     - Windows: Red
     - Thermal red: Orange
     - Thermal blue: Cyan

This is your complete digital twin with all components properly rotated!
""")
print("="*80)
