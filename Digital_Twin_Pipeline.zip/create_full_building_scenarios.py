#!/usr/bin/env python3
"""
Create Full Building with Adjusted Dimensions
Combine all facades with adjusted dimensions:
- Width (E-W): 30.5m (30m + 0.5m from east)
- Length (N-S): 32m (31m + 1m from north)
- Height: 17m
"""

import json
import copy
import math
import numpy as np

print("="*80)
print("CREATING FULL BUILDING WITH ADJUSTED DIMENSIONS")
print("="*80)

INPUT_FOLDER = "facade_Final"
OUTPUT_FOLDER = "facade_Final"

# New dimensions
TARGET_WIDTH = 30.5   # meters (E-W) - added 0.5m from east
TARGET_LENGTH = 32.0  # meters (N-S) - added 1m from north
TARGET_HEIGHT = 17.0  # meters

print(f"\nTarget dimensions:")
print(f"  Width (E-W): {TARGET_WIDTH}m (30m + 0.5m)")
print(f"  Length (N-S): {TARGET_LENGTH}m (31m + 1m)")
print(f"  Height: {TARGET_HEIGHT}m")

# Files to combine
facade_files = {
    'ground': 'Complete_Ground.geojson',
    'roof': 'Complete_Roof.geojson',
    'facade1': 'Facade1_Final.geojson',
    'facade2': 'Complete_Facade2_Rot0.5deg.geojson',
    'facade3': 'Complete_Facade3_Back_RotY0.5deg.geojson',
    'facade4': 'Complete_Facade4_Side_RotY1.5deg.geojson',
    'thermal_blue': 'Complete_Thermal_Blue_RotY0.5deg.geojson'
}

# Constants
LAT_CENTER = 33.773687
METERS_PER_DEGREE_LAT = 111000.0
METERS_PER_DEGREE_LON = 111000.0 * math.cos(math.radians(LAT_CENTER))

# Load all files and combine
print("\nLoading facade files...")
all_features = []
file_feature_counts = {}

for name, filename in facade_files.items():
    try:
        filepath = f"{INPUT_FOLDER}/{filename}"
        with open(filepath, 'r') as f:
            data = json.load(f)

        feature_count = len(data['features'])
        file_feature_counts[name] = feature_count
        all_features.extend(data['features'])
        print(f"  {name}: {feature_count} features from {filename}")
    except Exception as e:
        print(f"  WARNING: Could not load {filename}: {e}")

print(f"\nTotal features loaded: {len(all_features)}")

# Calculate current center and dimensions
print("\nAnalyzing current building...")
all_coords = []
for feature in all_features:
    coords = feature['geometry']['coordinates']
    if isinstance(coords, list) and len(coords) > 0:
        coord_array = coords[0] if isinstance(coords[0], list) else coords
        for c in coord_array:
            if isinstance(c, list) and len(c) == 3 and isinstance(c[0], (int, float)):
                all_coords.append(c)

center_lon = sum(c[0] for c in all_coords) / len(all_coords)
center_lat = sum(c[1] for c in all_coords) / len(all_coords)
center_alt = sum(c[2] for c in all_coords) / len(all_coords)

print(f"Current center: [{center_lon:.10f}, {center_lat:.10f}, {center_alt:.2f}]")

# Calculate current dimensions
lons = [c[0] for c in all_coords]
lats = [c[1] for c in all_coords]
alts = [c[2] for c in all_coords]

current_width_m = (max(lons) - min(lons)) * METERS_PER_DEGREE_LON
current_length_m = (max(lats) - min(lats)) * METERS_PER_DEGREE_LAT
current_height_m = max(alts) - min(alts)

print(f"Current dimensions:")
print(f"  Width (E-W): {current_width_m:.2f}m")
print(f"  Length (N-S): {current_length_m:.2f}m")
print(f"  Height: {current_height_m:.2f}m")

# Calculate scale factors
scale_width = TARGET_WIDTH / current_width_m
scale_length = TARGET_LENGTH / current_length_m
scale_height = TARGET_HEIGHT / current_height_m

print(f"\nScale factors:")
print(f"  Width: {scale_width:.4f}")
print(f"  Length: {scale_length:.4f}")
print(f"  Height: {scale_height:.4f}")

# Conversion functions
def gps_to_enu(lon, lat, alt):
    east = (lon - center_lon) * METERS_PER_DEGREE_LON
    north = (lat - center_lat) * METERS_PER_DEGREE_LAT
    up = alt - center_alt
    return np.array([east, north, up])

def enu_to_gps(east, north, up):
    lon = center_lon + (east / METERS_PER_DEGREE_LON)
    lat = center_lat + (north / METERS_PER_DEGREE_LAT)
    alt = center_alt + up
    return [lon, lat, alt]

# Create scenarios with different adjustments
scenarios = [
    {
        'name': 'Scenario1_Scaled',
        'description': 'Uniformly scaled to target dimensions',
        'scale_e': scale_width,
        'scale_n': scale_length,
        'scale_u': scale_height,
        'shift_e': 0.0,
        'shift_n': 0.0
    },
    {
        'name': 'Scenario2_ExtendEast',
        'description': 'Extended 0.5m to east',
        'scale_e': scale_width,
        'scale_n': scale_length,
        'scale_u': scale_height,
        'shift_e': 0.25,  # Shift center east by 0.25m
        'shift_n': 0.0
    },
    {
        'name': 'Scenario3_ExtendNorth',
        'description': 'Extended 1m to north',
        'scale_e': scale_width,
        'scale_n': scale_length,
        'scale_u': scale_height,
        'shift_e': 0.0,
        'shift_n': 0.5  # Shift center north by 0.5m
    },
    {
        'name': 'Scenario4_ExtendBoth',
        'description': 'Extended east and north',
        'scale_e': scale_width,
        'scale_n': scale_length,
        'scale_u': scale_height,
        'shift_e': 0.25,
        'shift_n': 0.5
    }
]

created_files = []

for scenario in scenarios:
    print(f"\n{'='*80}")
    print(f"Creating {scenario['name']}")
    print(f"Description: {scenario['description']}")
    print(f"{'='*80}")

    # Create combined data
    combined_data = {
        "type": "FeatureCollection",
        "name": scenario['name'],
        "crs": {
            "type": "name",
            "properties": {"name": "urn:ogc:def:crs:OGC:1.3:CRS84"}
        },
        "features": []
    }

    # Transform all features
    for feature in all_features:
        new_feature = copy.deepcopy(feature)
        coords = new_feature['geometry']['coordinates']

        if not isinstance(coords, list) or len(coords) == 0:
            combined_data['features'].append(new_feature)
            continue

        coord_array = coords[0] if isinstance(coords[0], list) else coords
        new_coords = []

        for c in coord_array:
            if isinstance(c, list) and len(c) == 3 and isinstance(c[0], (int, float)):
                # Convert to ENU
                enu = gps_to_enu(c[0], c[1], c[2])

                # Apply scaling
                scaled_enu = np.array([
                    enu[0] * scenario['scale_e'],
                    enu[1] * scenario['scale_n'],
                    enu[2] * scenario['scale_u']
                ])

                # Apply shift
                shifted_enu = scaled_enu + np.array([
                    scenario['shift_e'],
                    scenario['shift_n'],
                    0.0
                ])

                # Convert back to GPS
                new_gps = enu_to_gps(shifted_enu[0], shifted_enu[1], shifted_enu[2])
                new_coords.append(new_gps)
            else:
                new_coords.append(c)

        new_feature['geometry']['coordinates'] = [new_coords]

        # Update elevation_m
        if 'elevation_m' in new_feature['properties']:
            valid_coords = [c for c in new_coords if isinstance(c, list) and len(c) == 3]
            if len(valid_coords) > 0:
                avg_alt = sum(c[2] for c in valid_coords) / len(valid_coords)
                new_feature['properties']['elevation_m'] = avg_alt

        combined_data['features'].append(new_feature)

    # Verify dimensions
    verify_coords = []
    for f in combined_data['features']:
        coords = f['geometry']['coordinates'][0]
        for c in coords:
            if isinstance(c, list) and len(c) == 3:
                verify_coords.append(c)

    verify_lons = [c[0] for c in verify_coords]
    verify_lats = [c[1] for c in verify_coords]
    verify_alts = [c[2] for c in verify_coords]

    final_width = (max(verify_lons) - min(verify_lons)) * METERS_PER_DEGREE_LON
    final_length = (max(verify_lats) - min(verify_lats)) * METERS_PER_DEGREE_LAT
    final_height = max(verify_alts) - min(verify_alts)

    print(f"Final dimensions:")
    print(f"  Width: {final_width:.2f}m (target: {TARGET_WIDTH}m)")
    print(f"  Length: {final_length:.2f}m (target: {TARGET_LENGTH}m)")
    print(f"  Height: {final_height:.2f}m (target: {TARGET_HEIGHT}m)")
    print(f"  Features: {len(combined_data['features'])}")

    # Save
    output_file = f"{OUTPUT_FOLDER}/Complete_Building_{scenario['name']}.geojson"
    with open(output_file, 'w') as f:
        json.dump(combined_data, f, indent=2)

    file_size = len(json.dumps(combined_data)) / 1024
    print(f"✓ Saved: {output_file} ({file_size:.1f} KB)")

    created_files.append({
        'file': output_file,
        'name': scenario['name'],
        'width': final_width,
        'length': final_length,
        'height': final_height
    })

# Summary
print("\n" + "="*80)
print("✓✓✓ ALL BUILDING SCENARIOS CREATED ✓✓✓")
print("="*80)

print(f"\n{len(created_files)} complete building files created:")
for i, info in enumerate(created_files, 1):
    print(f"\n{i}. {info['name']}")
    print(f"   File: {info['file']}")
    print(f"   Dimensions: {info['width']:.1f}m × {info['length']:.1f}m × {info['height']:.1f}m")

print("\n" + "="*80)
print("TESTING INSTRUCTIONS:")
print("="*80)
print(f"""
Upload all {len(created_files)} scenarios to ArcGIS Online and compare:

Each file is a COMPLETE BUILDING with all components:
  - Ground and Roof
  - All 4 Facades (with their correct rotations)
  - All Windows (109 openings)
  - Blue Thermal Anomalies (42)

Target dimensions: {TARGET_WIDTH}m × {TARGET_LENGTH}m × {TARGET_HEIGHT}m

Configure in ArcGIS:
  - Elevation mode: "At an absolute height"
  - Use elevation from: "elevation_m" attribute

Compare scenarios to see which one:
  ✓ Has correct dimensions
  ✓ All facades connect properly
  ✓ Building looks complete and aligned

Tell me which scenario works best!
""")
print("="*80)
