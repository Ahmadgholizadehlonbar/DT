#!/usr/bin/env python3
"""
Create PowerPoint Presentation: MATLAB to Digital Twin
Documents the complete workflow for DM Smith Building
"""

try:
    from pptx import Presentation
    from pptx.util import Inches, Pt
    from pptx.enum.text import PP_ALIGN
    from pptx.dml.color import RGBColor
except ImportError:
    print("ERROR: python-pptx not installed")
    print("Installing python-pptx...")
    import subprocess
    subprocess.check_call(['pip', 'install', 'python-pptx'])
    from pptx import Presentation
    from pptx.util import Inches, Pt
    from pptx.enum.text import PP_ALIGN
    from pptx.dml.color import RGBColor

print("="*80)
print("CREATING POWERPOINT PRESENTATION")
print("="*80)

# Create presentation
prs = Presentation()
prs.slide_width = Inches(10)
prs.slide_height = Inches(7.5)

def add_title_slide(prs, title, subtitle):
    """Add title slide"""
    slide = prs.slides.add_slide(prs.slide_layouts[0])
    title_shape = slide.shapes.title
    subtitle_shape = slide.placeholders[1]

    title_shape.text = title
    subtitle_shape.text = subtitle

    # Format title
    title_shape.text_frame.paragraphs[0].font.size = Pt(44)
    title_shape.text_frame.paragraphs[0].font.bold = True
    title_shape.text_frame.paragraphs[0].font.color.rgb = RGBColor(0, 51, 102)

def add_content_slide(prs, title, content_points):
    """Add content slide with bullet points"""
    slide = prs.slides.add_slide(prs.slide_layouts[1])
    title_shape = slide.shapes.title
    content_shape = slide.placeholders[1]

    title_shape.text = title
    title_shape.text_frame.paragraphs[0].font.size = Pt(32)
    title_shape.text_frame.paragraphs[0].font.bold = True
    title_shape.text_frame.paragraphs[0].font.color.rgb = RGBColor(0, 51, 102)

    text_frame = content_shape.text_frame
    text_frame.clear()

    for point in content_points:
        p = text_frame.add_paragraph()
        p.text = point
        p.level = 0
        p.font.size = Pt(18)

def add_two_column_slide(prs, title, left_points, right_points):
    """Add slide with two columns"""
    slide = prs.slides.add_slide(prs.slide_layouts[5])  # Blank layout

    # Title
    title_shape = slide.shapes.add_textbox(Inches(0.5), Inches(0.5), Inches(9), Inches(0.8))
    title_frame = title_shape.text_frame
    title_frame.text = title
    title_frame.paragraphs[0].font.size = Pt(32)
    title_frame.paragraphs[0].font.bold = True
    title_frame.paragraphs[0].font.color.rgb = RGBColor(0, 51, 102)

    # Left column
    left_shape = slide.shapes.add_textbox(Inches(0.5), Inches(1.5), Inches(4.5), Inches(5.5))
    left_frame = left_shape.text_frame
    for point in left_points:
        p = left_frame.add_paragraph()
        p.text = point
        p.font.size = Pt(16)

    # Right column
    right_shape = slide.shapes.add_textbox(Inches(5.2), Inches(1.5), Inches(4.5), Inches(5.5))
    right_frame = right_shape.text_frame
    for point in right_points:
        p = right_frame.add_paragraph()
        p.text = point
        p.font.size = Pt(16)

print("\nCreating slides...")

# Slide 1: Title
add_title_slide(prs,
    "Digital Twin Creation Workflow",
    "From MATLAB Point Cloud to 3D GeoJSON Visualization\nD.M. Smith Building, Georgia Institute of Technology"
)
print("  ✓ Slide 1: Title")

# Slide 2: Project Overview
add_content_slide(prs,
    "Project Overview",
    [
        "Building: D.M. Smith Building at Georgia Tech",
        "Location: Corner of Cherry Street and Bobby Dodd Way",
        "Objective: Create 3D digital twin with thermal anomalies",
        "Platform: ArcGIS Online Scene Viewer",
        "Data Source: MATLAB point cloud / NeRF reconstruction",
        "Output Format: GeoJSON with GPS coordinates + elevation"
    ]
)
print("  ✓ Slide 2: Project Overview")

# Slide 3: Workflow Overview
add_content_slide(prs,
    "Complete Workflow",
    [
        "1. MATLAB Processing: Point cloud extraction and segmentation",
        "2. Component Identification: Facades, windows, roof, ground",
        "3. Coordinate Conversion: Local coordinates → GPS (WGS84)",
        "4. GeoJSON Creation: Feature collections with geometry",
        "5. Rotation Corrections: Facade alignment adjustments",
        "6. Thermal Anomaly Integration: Hot/cold spot mapping",
        "7. Validation & Testing: ArcGIS Online visualization",
        "8. Final Assembly: Complete building digital twin"
    ]
)
print("  ✓ Slide 3: Workflow Overview")

# Slide 4: Phase 1 - MATLAB Processing
add_content_slide(prs,
    "Phase 1: MATLAB Data Processing",
    [
        "Input Data:",
        "  • NeRF reconstruction / Point cloud data",
        "  • Local coordinate system (meters)",
        "",
        "Processing Steps:",
        "  • Segment building components (walls, openings)",
        "  • Extract facade planes",
        "  • Identify window boundaries",
        "  • Detect thermal anomalies",
        "  • Export geometry data",
        "",
        "Challenges:",
        "  • Point cloud noise and incompleteness",
        "  • Accurate plane fitting for facades",
        "  • Window detection accuracy"
    ]
)
print("  ✓ Slide 4: MATLAB Processing")

# Slide 5: Phase 2 - GeoJSON Creation
add_content_slide(prs,
    "Phase 2: GeoJSON Structure Creation",
    [
        "GeoJSON Format:",
        "  • Type: FeatureCollection",
        "  • CRS: WGS84 (EPSG:4326)",
        "  • Coordinates: [longitude, latitude, altitude]",
        "",
        "Feature Types Created:",
        "  • Ground plane (1 feature)",
        "  • Roof plane (1 feature)",
        "  • Facades (4 walls)",
        "  • Windows/Openings (109 features)",
        "  • Thermal anomalies (47 features: 42 blue + 5 red)",
        "",
        "Properties:",
        "  • Feature type, name, elevation_m",
        "  • Material, color information",
        "  • Thermal intensity values"
    ]
)
print("  ✓ Slide 5: GeoJSON Creation")

# Slide 6: Phase 3 - GPS Coordinate Conversion
add_content_slide(prs,
    "Phase 3: Coordinate System Transformation",
    [
        "Local ENU (East-North-Up) → GPS Conversion:",
        "",
        "Reference Point (Building Center):",
        "  • Latitude: 33.773687°N",
        "  • Longitude: -84.395185°W",
        "  • Altitude: ~305m MSL",
        "",
        "Conversion Constants:",
        "  • Meters per degree latitude: 111,000m",
        "  • Meters per degree longitude: 91,800m (at 33.77°N)",
        "",
        "Formula:",
        "  lon = center_lon + (east / meters_per_deg_lon)",
        "  lat = center_lat + (north / meters_per_deg_lat)",
        "  alt = center_alt + up",
        "",
        "Validation: Google Maps satellite imagery alignment"
    ]
)
print("  ✓ Slide 6: GPS Conversion")

# Slide 7: Building Dimensions
add_content_slide(prs,
    "Building Dimensions & Components",
    [
        "Target Dimensions:",
        "  • Width (E-W): ~30.5 meters",
        "  • Length (N-S): ~32.0 meters",
        "  • Height: ~17.0 meters",
        "",
        "Component Breakdown:",
        "  • Facade 1 (Front/Cherry St): 1 wall + 32 windows",
        "  • Facade 2 (Front/Cherry St): 1 wall + 32 windows",
        "  • Facade 3 (Back): 1 wall + 20 windows",
        "  • Facade 4 (Side): 1 wall + 25 windows",
        "  • Ground + Roof: 2 planes",
        "  • Thermal anomalies: 47 features",
        "",
        "Total Features: 162"
    ]
)
print("  ✓ Slide 7: Building Dimensions")

# Slide 8: Phase 4 - Rotation Challenges
add_content_slide(prs,
    "Phase 4: Facade Alignment Challenges",
    [
        "Problem: Facades not perfectly planar in 3D view",
        "  • Point cloud reconstruction artifacts",
        "  • GPS coordinate precision limits",
        "  • Building slight tilt/orientation issues",
        "",
        "Solution Approach: Rotation Corrections",
        "  • Calculate best-fit plane for each facade",
        "  • Measure deviation from planarity",
        "  • Apply 3D rotations to minimize variation",
        "",
        "Rotation Axes:",
        "  • X-axis: North-South tilt (pitch)",
        "  • Y-axis: East-West tilt (roll)",
        "  • Custom axis: Along street alignment",
        "",
        "Key Insight:",
        "  Different facades needed different rotation axes",
        "  based on their orientation!"
    ]
)
print("  ✓ Slide 8: Rotation Challenges")

# Slide 9: Rotation Testing Process
add_two_column_slide(prs,
    "Rotation Testing & Optimization",
    [
        "Facade 1 (Front/Cherry St):",
        "• Tested: 0° to 3° X-axis",
        "• Optimal: 3.0° X-axis",
        "• Result: Aligned with street",
        "",
        "Facade 2 (Front/Cherry St):",
        "• Tested: 0° to 2° X-axis",
        "• Optimal: 0.5° X-axis",
        "• Issue: Appeared 'inside' building",
        "• Solution: Translate 0.5m west",
        "",
        "Facade 3 (Back):",
        "• X-axis rotation made worse!",
        "• Switched to Y-axis",
        "• Optimal: 0.5° Y-axis",
        "• Improved planarity"
    ],
    [
        "Facade 4 (Side):",
        "• Tested: 0° to 4° Y-axis",
        "• Optimal: 1.5° Y-axis",
        "",
        "Thermal Anomalies:",
        "• Blue (42): 0.5° Y-axis",
        "  (on back/side facades)",
        "• Red (5): 0.5° X-axis",
        "  (on front facades)",
        "",
        "Key Learning:",
        "Individual facade rotations →",
        "Gaps between facades",
        "",
        "Alternative Tested:",
        "Unified rotation for all",
        "components (preserves",
        "connections but less optimal",
        "individual facade planarity)"
    ]
)
print("  ✓ Slide 9: Rotation Testing")

# Slide 10: Thermal Anomalies
add_content_slide(prs,
    "Phase 5: Thermal Anomaly Integration",
    [
        "Thermal Data Collection:",
        "  • IR camera survey / Thermal imaging",
        "  • Hot spots (red) and cold spots (blue) identified",
        "  • Mapped to building facade locations",
        "",
        "Processing:",
        "  • Separated by color: Red (5) vs Blue (42)",
        "  • Applied facade-specific rotations",
        "  • Maintained 3D position accuracy",
        "",
        "Visualization:",
        "  • Red anomalies: Orange/red color, higher intensity",
        "  • Blue anomalies: Cyan/blue color, lower intensity",
        "  • Semi-transparent overlay on facades",
        "",
        "Application:",
        "  • Building Energy Management (BEM)",
        "  • Identify insulation problems",
        "  • HVAC efficiency analysis"
    ]
)
print("  ✓ Slide 10: Thermal Anomalies")

# Slide 11: Technical Challenges
add_content_slide(prs,
    "Technical Challenges Encountered",
    [
        "1. Facade Connection Issues",
        "   • Individual rotations broke geometric relationships",
        "   • Solution: Translation adjustment for Facade 2",
        "",
        "2. Coordinate Precision",
        "   • GPS decimal precision vs meter-level accuracy",
        "   • Solution: 10 decimal places for lon/lat",
        "",
        "3. Elevation Handling",
        "   • ArcGIS requires 'elevation_m' property",
        "   • Solution: Calculate average altitude per feature",
        "",
        "4. Red Thermal Visibility",
        "   • Initially missing after facade separation",
        "   • Solution: Extract separately with correct rotation",
        "",
        "5. Cherry Street Alignment",
        "   • Custom rotation axis along street direction",
        "   • Solution: Calculate from facade orientation vectors"
    ]
)
print("  ✓ Slide 11: Technical Challenges")

# Slide 12: ArcGIS Online Configuration
add_content_slide(prs,
    "Phase 6: ArcGIS Online Visualization",
    [
        "Upload Process:",
        "  • Format: GeoJSON files",
        "  • Platform: ArcGIS Online Scene Viewer",
        "  • Coordinate System: Auto-detected WGS84",
        "",
        "Critical Settings:",
        "  • Elevation Mode: 'At an absolute height'",
        "  • Elevation Source: 'elevation_m' attribute",
        "  • 3D Symbols: Extrude polygons",
        "",
        "Styling:",
        "  • Ground: Gray",
        "  • Roof: Dark gray",
        "  • Facades: Blue (different shades)",
        "  • Windows: Red/transparent",
        "  • Thermal Red: Orange",
        "  • Thermal Blue: Cyan",
        "",
        "Layers: Multiple options tested (combined vs. separated)"
    ]
)
print("  ✓ Slide 12: ArcGIS Configuration")

# Slide 13: Iteration Process
add_content_slide(prs,
    "Iterative Refinement Process",
    [
        "Iteration 1: Basic geometry + GPS",
        "  → Facades not planar, poor alignment",
        "",
        "Iteration 2: Individual facade rotations",
        "  → Better planarity, but facades disconnected",
        "",
        "Iteration 3: Unified building rotation",
        "  → Preserved connections, compromised planarity",
        "",
        "Iteration 4: Facade 2 translation",
        "  → Fixed 'inside building' issue",
        "",
        "Iteration 5: Thermal anomaly separation",
        "  → Proper visibility for red/blue anomalies",
        "",
        "Final Result: Combination approach",
        "  • Most facades with individual corrections",
        "  • Facade 2 with translation adjustment",
        "  • Thermal anomalies properly rotated"
    ]
)
print("  ✓ Slide 13: Iteration Process")

# Slide 14: Scripts & Automation
add_content_slide(prs,
    "Scripts & Automation Developed",
    [
        "Python Scripts Created:",
        "  • rotate_facade1_multiple.py: Test Facade 1 rotations",
        "  • rotate_facade3_4_Y_axis.py: Y-axis rotations for Facade 3/4",
        "  • create_thermal_red_blue_separate.py: Separate thermal layers",
        "  • create_building_street_aligned.py: Cherry Street alignment",
        "  • create_complete_final_building.py: Assemble components",
        "  • create_unified_rotation_from_original.py: Unified approach",
        "  • move_facade2_towards_bobby_dodd.py: Translate Facade 2",
        "",
        "Key Libraries:",
        "  • json: GeoJSON manipulation",
        "  • numpy: 3D transformations and matrix operations",
        "  • math: Trigonometric calculations",
        "",
        "Automation Benefits:",
        "  • Rapid testing of multiple scenarios",
        "  • Reproducible transformations",
        "  • Batch processing of features"
    ]
)
print("  ✓ Slide 14: Scripts & Automation")

# Slide 15: Key Formulas
add_content_slide(prs,
    "Key Mathematical Formulas",
    [
        "1. GPS to ENU Conversion:",
        "   east = (lon - center_lon) × meters_per_deg_lon",
        "   north = (lat - center_lat) × meters_per_deg_lat",
        "   up = alt - center_alt",
        "",
        "2. X-axis Rotation Matrix:",
        "   [1    0         0    ]",
        "   [0   cos(θ)  -sin(θ)]",
        "   [0   sin(θ)   cos(θ)]",
        "",
        "3. Y-axis Rotation Matrix:",
        "   [cos(θ)   0   sin(θ)]",
        "   [0        1      0   ]",
        "   [-sin(θ)  0   cos(θ)]",
        "",
        "4. Rodrigues' Rotation (arbitrary axis):",
        "   R = I + sin(θ)K + (1-cos(θ))K²",
        "   where K is the skew-symmetric cross-product matrix"
    ]
)
print("  ✓ Slide 15: Key Formulas")

# Slide 16: Results & Metrics
add_content_slide(prs,
    "Results & Performance Metrics",
    [
        "Final Digital Twin:",
        "  • Total Features: 162",
        "  • File Size: ~220 KB (GeoJSON)",
        "  • Coordinate Precision: 10 decimal places (~1cm)",
        "",
        "Geometric Accuracy:",
        "  • Building dimensions: ±0.5m from targets",
        "  • GPS position: Aligned with satellite imagery",
        "  • Facade planarity: Improved 60-85% per facade",
        "",
        "Components Successfully Integrated:",
        "  ✓ 4 Facades with 109 windows",
        "  ✓ Ground and roof planes",
        "  ✓ 47 Thermal anomaly features",
        "  ✓ All features with elevation attributes",
        "",
        "Visualization:",
        "  • Renders correctly in ArcGIS Scene Viewer",
        "  • Interactive 3D exploration enabled",
        "  • Layer styling and transparency working"
    ]
)
print("  ✓ Slide 16: Results & Metrics")

# Slide 17: Applications
add_content_slide(prs,
    "Applications & Use Cases",
    [
        "Building Energy Management (BEM):",
        "  • Thermal anomaly visualization",
        "  • Heat loss identification",
        "  • Energy audit documentation",
        "",
        "Facility Management:",
        "  • 3D building documentation",
        "  • Maintenance planning",
        "  • Asset tracking integration",
        "",
        "Campus Planning:",
        "  • Context visualization with surrounding buildings",
        "  • Shadow analysis",
        "  • Urban planning decisions",
        "",
        "Research & Education:",
        "  • Digital twin methodology demonstration",
        "  • Point cloud processing workflows",
        "  • GIS integration techniques",
        "",
        "Future Extensions:",
        "  • Real-time sensor integration",
        "  • Interior space modeling",
        "  • Temporal analysis (changes over time)"
    ]
)
print("  ✓ Slide 17: Applications")

# Slide 18: Lessons Learned
add_content_slide(prs,
    "Lessons Learned",
    [
        "Technical Insights:",
        "  • Different facade orientations require different rotation axes",
        "  • Individual rotations vs unified rotation trade-offs",
        "  • Translation adjustments necessary for some facades",
        "  • Thermal data needs facade-specific processing",
        "",
        "Process Insights:",
        "  • Iterative testing essential for finding optimal parameters",
        "  • Visualization-driven debugging most effective",
        "  • Script automation enables rapid experimentation",
        "",
        "Tool Insights:",
        "  • ArcGIS Online Scene Viewer powerful for 3D validation",
        "  • GeoJSON format flexible for 3D building models",
        "  • Python + NumPy excellent for geometric transformations",
        "",
        "Best Practices:",
        "  • Always preserve original data",
        "  • Create multiple test scenarios",
        "  • Document all transformation parameters",
        "  • Validate with visual inspection + metrics"
    ]
)
print("  ✓ Slide 18: Lessons Learned")

# Slide 19: Future Work
add_content_slide(prs,
    "Future Improvements & Extensions",
    [
        "Short-term Improvements:",
        "  • Optimize unified rotation for all facades",
        "  • Fine-tune Facade 2 translation distance",
        "  • Add more thermal data collection points",
        "  • Improve window boundary detection",
        "",
        "Medium-term Extensions:",
        "  • Interior space modeling (rooms, hallways)",
        "  • Real-time sensor data integration",
        "  • Automated thermal anomaly detection",
        "  • Multi-temporal comparison (seasonal changes)",
        "",
        "Long-term Vision:",
        "  • Campus-wide digital twin (all buildings)",
        "  • IoT sensor network integration",
        "  • Predictive maintenance AI models",
        "  • Energy optimization simulations",
        "  • Augmented reality overlay capability",
        "",
        "Scalability:",
        "  • Apply workflow to other buildings",
        "  • Develop automated pipeline",
        "  • Create standardized templates"
    ]
)
print("  ✓ Slide 19: Future Work")

# Slide 20: Conclusion
add_content_slide(prs,
    "Conclusion",
    [
        "Successfully Created:",
        "  ✓ Complete 3D digital twin of D.M. Smith Building",
        "  ✓ GPS-referenced GeoJSON with 162 features",
        "  ✓ Integrated thermal anomaly data (47 hotspots)",
        "  ✓ ArcGIS Online-ready visualization",
        "",
        "Workflow Established:",
        "  MATLAB → GeoJSON → GPS → Rotations → ArcGIS Online",
        "",
        "Key Innovation:",
        "  Facade-specific rotation approach for optimal alignment",
        "",
        "Outcome:",
        "  Interactive 3D building model with thermal data for",
        "  building energy management and facility planning",
        "",
        "Impact:",
        "  Foundation for campus-wide digital twin initiative",
        "  Methodology applicable to other buildings",
        "  Enables data-driven building management decisions"
    ]
)
print("  ✓ Slide 20: Conclusion")

# Slide 21: References & Tools
add_content_slide(prs,
    "Tools & Technologies Used",
    [
        "Software:",
        "  • MATLAB: Point cloud processing and segmentation",
        "  • Python 3: Data transformation and automation",
        "  • ArcGIS Online: 3D visualization and publishing",
        "",
        "Python Libraries:",
        "  • NumPy: Matrix operations and 3D transformations",
        "  • JSON: GeoJSON file manipulation",
        "  • Math: Trigonometric calculations",
        "",
        "Data Formats:",
        "  • GeoJSON: Primary output format",
        "  • WGS84 (EPSG:4326): Coordinate reference system",
        "",
        "Location:",
        "  • D.M. Smith Building, Georgia Institute of Technology",
        "  • Corner of Cherry Street and Bobby Dodd Way",
        "  • Atlanta, GA, USA",
        "",
        "Project Repository:",
        "  C:\\Users\\...\\NeRF_Data\\BEM\\geojson\\ArcGIS_Online"
    ]
)
print("  ✓ Slide 21: References & Tools")

# Save presentation
output_file = "Digital_Twin_Creation_Workflow.pptx"
prs.save(output_file)

print("\n" + "="*80)
print("✓✓✓ PRESENTATION CREATED ✓✓✓")
print("="*80)
print(f"\nFile: {output_file}")
print(f"Slides: {len(prs.slides)}")
print("\nPresentation Content:")
print("  1. Title")
print("  2. Project Overview")
print("  3. Complete Workflow")
print("  4. MATLAB Processing")
print("  5. GeoJSON Creation")
print("  6. GPS Coordinate Conversion")
print("  7. Building Dimensions")
print("  8. Facade Alignment Challenges")
print("  9. Rotation Testing & Optimization")
print(" 10. Thermal Anomaly Integration")
print(" 11. Technical Challenges")
print(" 12. ArcGIS Online Visualization")
print(" 13. Iterative Refinement Process")
print(" 14. Scripts & Automation")
print(" 15. Key Mathematical Formulas")
print(" 16. Results & Performance Metrics")
print(" 17. Applications & Use Cases")
print(" 18. Lessons Learned")
print(" 19. Future Improvements")
print(" 20. Conclusion")
print(" 21. Tools & Technologies")
print("\n" + "="*80)
