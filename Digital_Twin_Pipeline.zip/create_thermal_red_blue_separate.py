#!/usr/bin/env python3
"""
Create Separate Red and Blue Thermal Anomaly Layers
Apply different rotations based on which facades they're on
"""

import json
import copy
import math
import numpy as np

print("="*80)
print("CREATING SEPARATE RED AND BLUE THERMAL LAYERS")
print("="*80)

OUTPUT_FOLDER = "New folder"

# Rotation for red (front facades) and blue (back/side facades)
RED_ROTATION_DEGREES = 0.5   # X-axis for front facades
BLUE_ROTATION_DEGREES = 0.5  # Y-axis for back/side facades

# Constants
LAT_CENTER = 33.773687
METERS_PER_DEGREE_LAT = 111000.0
METERS_PER_DEGREE_LON = 111000.0 * math.cos(math.radians(LAT_CENTER))

# Load Complete.geojson
print("\nLoading Complete.geojson...")
with open('Complete.geojson', 'r') as f:
    data = json.load(f)

print(f"Total features: {len(data['features'])}")

# Separate red and blue thermal anomalies
red_thermal_indices = []
blue_thermal_indices = []

for i, feature in enumerate(data['features']):
    if feature['properties'].get('type') == 'thermal_anomaly':
        name = feature['properties'].get('name', '')
        if 'red' in name.lower():
            red_thermal_indices.append(i)
        elif 'blue' in name.lower():
            blue_thermal_indices.append(i)

print(f"\nFound thermal anomalies:")
print(f"  Red: {len(red_thermal_indices)}")
print(f"  Blue: {len(blue_thermal_indices)}")

def create_thermal_layer(indices, name, rotation_degrees, rotation_axis='X'):
    """Create a thermal layer with specified rotation"""

    print(f"\n{'='*80}")
    print(f"Creating {name}")
    print(f"{'='*80}")

    # Create data structure
    thermal_data = {
        "type": "FeatureCollection",
        "name": name,
        "crs": data.get("crs", {
            "type": "name",
            "properties": {"name": "urn:ogc:def:crs:OGC:1.3:CRS84"}
        }),
        "features": []
    }

    for idx in indices:
        thermal_data['features'].append(copy.deepcopy(data['features'][idx]))

    print(f"Features: {len(thermal_data['features'])}")

    # Calculate GPS center
    all_coords = []
    for feature in thermal_data['features']:
        coords = feature['geometry']['coordinates']
        if isinstance(coords, list) and len(coords) > 0:
            coord_array = coords[0] if isinstance(coords[0], list) else coords
            for c in coord_array:
                if isinstance(c, list) and len(c) == 3 and isinstance(c[0], (int, float)):
                    all_coords.append(c)

    center_lon = sum(c[0] for c in all_coords) / len(all_coords)
    center_lat = sum(c[1] for c in all_coords) / len(all_coords)
    center_alt = sum(c[2] for c in all_coords) / len(all_coords)

    print(f"Center: [{center_lon:.10f}, {center_lat:.10f}, {center_alt:.2f}]")
    print(f"Rotation: {rotation_degrees}° {rotation_axis}-axis")

    def gps_to_enu(lon, lat, alt):
        east = (lon - center_lon) * METERS_PER_DEGREE_LON
        north = (lat - center_lat) * METERS_PER_DEGREE_LAT
        up = alt - center_alt
        return np.array([east, north, up])

    def enu_to_gps(east, north, up):
        lon = center_lon + (east / METERS_PER_DEGREE_LON)
        lat = center_lat + (north / METERS_PER_DEGREE_LAT)
        alt = center_alt + up
        return [lon, lat, alt]

    # Create rotation matrix
    rotation_angle_rad = math.radians(rotation_degrees)
    cos_a = math.cos(rotation_angle_rad)
    sin_a = math.sin(rotation_angle_rad)

    if rotation_axis == 'X':
        # X-axis rotation (for front facades)
        R = np.array([
            [1,     0,      0],
            [0,  cos_a, -sin_a],
            [0,  sin_a,  cos_a]
        ])
    else:  # Y-axis
        # Y-axis rotation (for back/side facades)
        R = np.array([
            [cos_a,  0,  sin_a],
            [0,      1,      0],
            [-sin_a, 0,  cos_a]
        ])

    # Apply rotation
    rotated_thermal = copy.deepcopy(thermal_data)

    for feature in rotated_thermal['features']:
        coords = feature['geometry']['coordinates']
        if not isinstance(coords, list) or len(coords) == 0:
            continue

        coord_array = coords[0] if isinstance(coords[0], list) else coords
        new_coords = []

        for c in coord_array:
            if isinstance(c, list) and len(c) == 3 and isinstance(c[0], (int, float)):
                enu = gps_to_enu(c[0], c[1], c[2])
                rotated_enu = R @ enu
                new_gps = enu_to_gps(rotated_enu[0], rotated_enu[1], rotated_enu[2])
                new_coords.append(new_gps)
            else:
                new_coords.append(c)

        feature['geometry']['coordinates'] = [new_coords]

        # Update elevation_m
        if 'elevation_m' in feature['properties']:
            valid_coords = [c for c in new_coords if isinstance(c, list) and len(c) == 3]
            if len(valid_coords) > 0:
                avg_alt = sum(c[2] for c in valid_coords) / len(valid_coords)
                feature['properties']['elevation_m'] = avg_alt

    print(f"Rotated {len(rotated_thermal['features'])} features")

    # Save
    output_file = f'{OUTPUT_FOLDER}/Complete_Thermal_{name}_Rot{rotation_axis}{rotation_degrees}deg.geojson'
    with open(output_file, 'w') as f:
        json.dump(rotated_thermal, f, indent=2)

    file_size = len(json.dumps(rotated_thermal)) / 1024
    print(f"✓ Saved: {output_file} ({file_size:.1f} KB)")

    return output_file

# Create red thermal layer (X-axis rotation like front facades)
red_file = create_thermal_layer(
    red_thermal_indices,
    "Red",
    RED_ROTATION_DEGREES,
    'X'
)

# Create blue thermal layer (Y-axis rotation like back/side facades)
blue_file = create_thermal_layer(
    blue_thermal_indices,
    "Blue",
    BLUE_ROTATION_DEGREES,
    'Y'
)

# Summary
print("\n" + "="*80)
print("✓✓✓ THERMAL LAYERS CREATED ✓✓✓")
print("="*80)

print(f"\n2 thermal files created:")
print(f"  1. {red_file}")
print(f"  2. {blue_file}")

print("\n" + "="*80)
print("UPLOAD INSTRUCTIONS:")
print("="*80)
print(f"""
Upload both thermal files to ArcGIS Online:

1. Complete_Thermal_Red_RotX{RED_ROTATION_DEGREES}deg.geojson
   - {len(red_thermal_indices)} red (hot) thermal anomalies
   - Rotation: {RED_ROTATION_DEGREES}° X-axis (matches front facades)
   - Style: Orange/Red color

2. Complete_Thermal_Blue_RotY{BLUE_ROTATION_DEGREES}deg.geojson
   - {len(blue_thermal_indices)} blue (cold) thermal anomalies
   - Rotation: {BLUE_ROTATION_DEGREES}° Y-axis (matches back/side facades)
   - Style: Blue/Cyan color

Configuration for both:
  - Elevation mode: "At an absolute height"
  - Use elevation from: "elevation_m" attribute
  - Transparency: ~50% to see through building

Now red thermal anomalies should be visible with proper rotation!
""")
print("="*80)
