#!/usr/bin/env python3
"""
Create Building with Unified Rotation from Original Complete.geojson
Start with original unrotated data and apply single unified rotation
This preserves facade connections and building geometry
"""

import json
import copy
import math
import numpy as np

print("="*80)
print("CREATING BUILDING WITH UNIFIED ROTATION FROM ORIGINAL")
print("="*80)

OUTPUT_FOLDER = "facade_Final"

# Constants
LAT_CENTER = 33.773687
METERS_PER_DEGREE_LAT = 111000.0
METERS_PER_DEGREE_LON = 111000.0 * math.cos(math.radians(LAT_CENTER))

# Load original Complete.geojson
print("\nLoading original Complete.geojson...")
with open('Complete.geojson', 'r') as f:
    original_data = json.load(f)

all_features = original_data['features']
print(f"Total features: {len(all_features)}")

# Analyze feature types
feature_types = {}
for feature in all_features:
    ftype = feature['properties'].get('type', 'unknown')
    if ftype not in feature_types:
        feature_types[ftype] = 0
    feature_types[ftype] += 1

print("\nFeature breakdown:")
for ftype, count in sorted(feature_types.items()):
    print(f"  {ftype}: {count}")

# Calculate building center
print("\nCalculating building center...")
all_coords = []
for feature in all_features:
    coords = feature['geometry']['coordinates']
    if isinstance(coords, list) and len(coords) > 0:
        coord_array = coords[0] if isinstance(coords[0], list) else coords
        for c in coord_array:
            if isinstance(c, list) and len(c) == 3 and isinstance(c[0], (int, float)):
                all_coords.append(c)

center_lon = sum(c[0] for c in all_coords) / len(all_coords)
center_lat = sum(c[1] for c in all_coords) / len(all_coords)
center_alt = sum(c[2] for c in all_coords) / len(all_coords)

print(f"Building center: [{center_lon:.10f}, {center_lat:.10f}, {center_alt:.2f}]")

# Calculate original dimensions
lons = [c[0] for c in all_coords]
lats = [c[1] for c in all_coords]
alts = [c[2] for c in all_coords]

orig_width_m = (max(lons) - min(lons)) * METERS_PER_DEGREE_LON
orig_length_m = (max(lats) - min(lats)) * METERS_PER_DEGREE_LAT
orig_height_m = max(alts) - min(alts)

print(f"Original dimensions (unrotated):")
print(f"  Width (E-W): {orig_width_m:.2f}m")
print(f"  Length (N-S): {orig_length_m:.2f}m")
print(f"  Height: {orig_height_m:.2f}m")

# Conversion functions
def gps_to_enu(lon, lat, alt):
    east = (lon - center_lon) * METERS_PER_DEGREE_LON
    north = (lat - center_lat) * METERS_PER_DEGREE_LAT
    up = alt - center_alt
    return np.array([east, north, up])

def enu_to_gps(east, north, up):
    lon = center_lon + (east / METERS_PER_DEGREE_LON)
    lat = center_lat + (north / METERS_PER_DEGREE_LAT)
    alt = center_alt + up
    return [lon, lat, alt]

def apply_unified_rotation(features, rotation_matrix, scenario_name):
    """Apply the same rotation to all features"""
    rotated_features = []

    for feature in features:
        new_feature = copy.deepcopy(feature)
        coords = new_feature['geometry']['coordinates']

        if not isinstance(coords, list) or len(coords) == 0:
            rotated_features.append(new_feature)
            continue

        coord_array = coords[0] if isinstance(coords[0], list) else coords
        new_coords = []

        for c in coord_array:
            if isinstance(c, list) and len(c) == 3 and isinstance(c[0], (int, float)):
                # Convert to ENU
                enu = gps_to_enu(c[0], c[1], c[2])

                # Apply rotation around building center
                rotated_enu = rotation_matrix @ enu

                # Convert back to GPS
                new_gps = enu_to_gps(rotated_enu[0], rotated_enu[1], rotated_enu[2])
                new_coords.append(new_gps)
            else:
                new_coords.append(c)

        new_feature['geometry']['coordinates'] = [new_coords]

        # Update elevation_m
        if 'elevation_m' in new_feature['properties']:
            valid_coords = [c for c in new_coords if isinstance(c, list) and len(c) == 3]
            if len(valid_coords) > 0:
                avg_alt = sum(c[2] for c in valid_coords) / len(valid_coords)
                new_feature['properties']['elevation_m'] = avg_alt

        rotated_features.append(new_feature)

    return rotated_features

def calculate_facade_planarity(features, facade_name):
    """Calculate planarity metric for a facade"""
    facade_coords = []
    for feature in features:
        if facade_name.lower() in feature['properties'].get('name', '').lower():
            coords = feature['geometry']['coordinates']
            if isinstance(coords, list) and len(coords) > 0:
                coord_array = coords[0] if isinstance(coords[0], list) else coords
                for c in coord_array:
                    if isinstance(c, list) and len(c) == 3:
                        # Convert to ENU for analysis
                        enu = gps_to_enu(c[0], c[1], c[2])
                        facade_coords.append(enu)

    if len(facade_coords) < 3:
        return None

    # Calculate standard deviation in each direction
    coords_array = np.array(facade_coords)
    std_e = np.std(coords_array[:, 0])
    std_n = np.std(coords_array[:, 1])
    std_u = np.std(coords_array[:, 2])

    return {'std_e': std_e, 'std_n': std_n, 'std_u': std_u}

# Test scenarios with different unified rotations
scenarios = [
    {
        'name': 'Original_NoRotation',
        'description': 'Original data without rotation',
        'axis': None,
        'angle': 0
    },
    {
        'name': 'Unified_X_0.5deg',
        'description': '0.5° X-axis (small correction)',
        'axis': 'X',
        'angle': 0.5
    },
    {
        'name': 'Unified_X_1.0deg',
        'description': '1.0° X-axis (moderate correction)',
        'axis': 'X',
        'angle': 1.0
    },
    {
        'name': 'Unified_X_1.5deg',
        'description': '1.5° X-axis (larger correction)',
        'axis': 'X',
        'angle': 1.5
    },
    {
        'name': 'Unified_X_2.0deg',
        'description': '2.0° X-axis (strong correction)',
        'axis': 'X',
        'angle': 2.0
    }
]

created_files = []

for scenario in scenarios:
    print(f"\n{'='*80}")
    print(f"Creating {scenario['name']}")
    print(f"Description: {scenario['description']}")
    print(f"{'='*80}")

    # Create rotation matrix
    if scenario['axis'] == 'X':
        angle_rad = math.radians(scenario['angle'])
        cos_a = math.cos(angle_rad)
        sin_a = math.sin(angle_rad)
        R = np.array([
            [1,     0,      0],
            [0,  cos_a, -sin_a],
            [0,  sin_a,  cos_a]
        ])
    elif scenario['axis'] == 'Y':
        angle_rad = math.radians(scenario['angle'])
        cos_a = math.cos(angle_rad)
        sin_a = math.sin(angle_rad)
        R = np.array([
            [cos_a,  0,  sin_a],
            [0,      1,      0],
            [-sin_a, 0,  cos_a]
        ])
    else:
        # No rotation
        R = np.eye(3)

    # Apply rotation to all features
    rotated_features = apply_unified_rotation(all_features, R, scenario['name'])

    # Create complete building
    complete_building = {
        "type": "FeatureCollection",
        "name": f"DM_Smith_Building_{scenario['name']}",
        "crs": {
            "type": "name",
            "properties": {"name": "urn:ogc:def:crs:OGC:1.3:CRS84"}
        },
        "properties": {
            "building_name": "D.M. Smith Building",
            "location": "Georgia Institute of Technology",
            "total_features": len(rotated_features),
            "unified_rotation": scenario['description'],
            "rotation_axis": scenario['axis'],
            "rotation_degrees": scenario['angle'],
            "note": "ALL components rotated together to preserve facade connections"
        },
        "features": rotated_features
    }

    # Verify dimensions
    verify_coords = []
    for f in complete_building['features']:
        coords = f['geometry']['coordinates'][0]
        for c in coords:
            if isinstance(c, list) and len(c) == 3:
                verify_coords.append(c)

    verify_lons = [c[0] for c in verify_coords]
    verify_lats = [c[1] for c in verify_coords]
    verify_alts = [c[2] for c in verify_coords]

    final_width = (max(verify_lons) - min(verify_lons)) * METERS_PER_DEGREE_LON
    final_length = (max(verify_lats) - min(verify_lats)) * METERS_PER_DEGREE_LAT
    final_height = max(verify_alts) - min(verify_alts)

    print(f"Dimensions:")
    print(f"  Width (E-W): {final_width:.2f}m")
    print(f"  Length (N-S): {final_length:.2f}m")
    print(f"  Height: {final_height:.2f}m")
    print(f"  Features: {len(complete_building['features'])}")

    # Calculate facade planarity metrics
    print("\nFacade planarity (std dev in meters):")
    for facade_num in [1, 2, 3, 4]:
        planarity = calculate_facade_planarity(rotated_features, f"facade{facade_num}")
        if planarity:
            print(f"  Facade {facade_num}: E={planarity['std_e']:.2f}m, N={planarity['std_n']:.2f}m, U={planarity['std_u']:.2f}m")

    # Save
    output_file = f"{OUTPUT_FOLDER}/Complete_Building_{scenario['name']}.geojson"
    with open(output_file, 'w') as f:
        json.dump(complete_building, f, indent=2)

    file_size = len(json.dumps(complete_building)) / 1024
    print(f"✓ Saved: {output_file} ({file_size:.1f} KB)")

    created_files.append({
        'file': output_file,
        'name': scenario['name'],
        'rotation': f"{scenario['angle']}° {scenario['axis'] or 'None'}",
        'width': final_width,
        'length': final_length,
        'height': final_height
    })

# Summary
print("\n" + "="*80)
print("✓✓✓ UNIFIED ROTATION BUILDINGS CREATED ✓✓✓")
print("="*80)

print(f"\n{len(created_files)} building versions created from ORIGINAL data:")
for i, info in enumerate(created_files, 1):
    print(f"\n{i}. {info['name']}")
    print(f"   Rotation: {info['rotation']}")
    print(f"   Dimensions: {info['width']:.1f}m × {info['length']:.1f}m × {info['height']:.1f}m")
    print(f"   File: {info['file']}")

print("\n" + "="*80)
print("KEY ADVANTAGES OF UNIFIED ROTATION:")
print("="*80)
print("""
✓ ALL components rotated together (same rotation for entire building)
✓ Preserves original facade connections - no gaps
✓ Facade 2 will NOT be "inside" the building
✓ Facades along Cherry Street stay aligned
✓ Ground and roof stay properly aligned with facades
✓ Thermal anomalies stay in correct positions

TRADE-OFF:
× Individual facades may not be perfectly flat
× Single rotation is a compromise for all facades

TESTING:
Upload all versions to ArcGIS Online and check:
  1. Do facades connect properly? (no gaps, no overlaps)
  2. Is Facade 2 aligned with building edge?
  3. Does building look correct along Cherry Street?
  4. Which rotation gives best overall result?

Expected: 0.5° to 1.5° X-axis should give good results
""")
print("="*80)
