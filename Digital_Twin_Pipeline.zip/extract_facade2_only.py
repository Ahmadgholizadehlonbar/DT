#!/usr/bin/env python3
"""
Extract ONLY Facade 2 (moved version) as a separate file
"""

import json

print("="*80)
print("EXTRACTING FACADE 2 ONLY")
print("="*80)

INPUT_FILE = "facade_Final/Complete_Facade2_Moved_0.5m_BobbyDodd.geojson"
OUTPUT_FOLDER = "facade_Final"

# Load the moved building file
print(f"\nLoading {INPUT_FILE}...")
with open(INPUT_FILE, 'r') as f:
    data = json.load(f)

print(f"Total features in file: {len(data['features'])}")

# Extract only Facade 2 features
print("\nExtracting Facade 2 features...")
facade2_features = []

for feature in data['features']:
    name = feature['properties'].get('name', '').lower()

    if 'facade2' in name or 'facade_2' in name:
        facade2_features.append(feature)
        print(f"  ✓ {feature['properties'].get('name')}")

print(f"\nTotal Facade 2 features: {len(facade2_features)}")

# Create Facade 2 only file
facade2_data = {
    "type": "FeatureCollection",
    "name": "Facade2_Moved_0.5m_BobbyDodd",
    "crs": {
        "type": "name",
        "properties": {"name": "urn:ogc:def:crs:OGC:1.3:CRS84"}
    },
    "properties": {
        "description": "Facade 2 moved 0.5m towards Bobby Dodd Way along Cherry Street axis",
        "total_features": len(facade2_features),
        "components": {
            "facade_wall": 1,
            "windows": len(facade2_features) - 1
        }
    },
    "features": facade2_features
}

# Save
output_file = f"{OUTPUT_FOLDER}/Facade2_ONLY_Moved_0.5m.geojson"
with open(output_file, 'w') as f:
    json.dump(facade2_data, f, indent=2)

file_size = len(json.dumps(facade2_data)) / 1024

print("\n" + "="*80)
print("✓✓✓ FACADE 2 EXTRACTED ✓✓✓")
print("="*80)
print(f"\nFile: {output_file} ({file_size:.1f} KB)")
print(f"Features: {len(facade2_features)} (1 wall + {len(facade2_features)-1} windows)")
print(f"\nThis file contains ONLY Facade 2 with the 0.5m movement applied.")
print("Upload this to replace your current Facade 2 layer.")
print("="*80)
