#!/usr/bin/env python3
"""
Move Facade 2 towards Bobby Dodd Way along Cherry Street axis
Translation only, no rotation
"""

import json
import copy
import math
import numpy as np

print("="*80)
print("MOVING FACADE 2 TOWARDS BOBBY DODD WAY")
print("="*80)

OUTPUT_FOLDER = "facade_Final"

# Constants
LAT_CENTER = 33.773687
METERS_PER_DEGREE_LAT = 111000.0
METERS_PER_DEGREE_LON = 111000.0 * math.cos(math.radians(LAT_CENTER))

# Movement parameters
MOVE_DISTANCE = 0.5  # meters towards Bobby Dodd

# Load original Complete.geojson
print("\nLoading original Complete.geojson...")
with open('Complete.geojson', 'r') as f:
    data = json.load(f)

print(f"Total features: {len(data['features'])}")

# Identify Facade 2 features
print("\nIdentifying Facade 2 features...")
facade2_indices = []

for i, feature in enumerate(data['features']):
    name = feature['properties'].get('name', '').lower()
    ftype = feature['properties'].get('type', '')

    # Facade 2 is the second front facade
    if 'facade2' in name or ('facade_2' in name):
        facade2_indices.append(i)
        print(f"  Found: {feature['properties'].get('name')} (index {i}, type: {ftype})")

print(f"\nTotal Facade 2 features found: {len(facade2_indices)}")

if len(facade2_indices) == 0:
    print("ERROR: No Facade 2 features found!")
    print("\nSearching for all facade features...")
    for i, feature in enumerate(data['features']):
        name = feature['properties'].get('name', '')
        if 'facade' in name.lower():
            print(f"  {name}")
    exit(1)

# Calculate Cherry Street axis direction from Facade 1
print("\n" + "="*80)
print("CALCULATING CHERRY STREET AXIS")
print("="*80)

# Find Facade 1 to determine Cherry Street orientation
facade1_features = []
for feature in data['features']:
    name = feature['properties'].get('name', '').lower()
    if ('facade1' in name or 'facade_1' in name) and feature['properties'].get('type') == 'facade':
        facade1_features.append(feature)

if facade1_features:
    # Get coordinates of Facade 1 wall
    facade1_coords = []
    coords = facade1_features[0]['geometry']['coordinates']
    if isinstance(coords, list) and len(coords) > 0:
        coord_array = coords[0] if isinstance(coords[0], list) else coords
        for c in coord_array:
            if isinstance(c, list) and len(c) == 3:
                facade1_coords.append(c)

    # Calculate center
    center_lon = sum(c[0] for c in facade1_coords) / len(facade1_coords)
    center_lat = sum(c[1] for c in facade1_coords) / len(facade1_coords)

    # Get first two corners to determine direction
    corner1 = facade1_coords[0]
    corner2 = facade1_coords[1]

    # Convert to ENU (meters)
    e1 = (corner1[0] - center_lon) * METERS_PER_DEGREE_LON
    n1 = (corner1[1] - center_lat) * METERS_PER_DEGREE_LAT
    e2 = (corner2[0] - center_lon) * METERS_PER_DEGREE_LON
    n2 = (corner2[1] - center_lat) * METERS_PER_DEGREE_LAT

    # Direction along facade (Cherry Street axis)
    cherry_street_direction = np.array([e2 - e1, n2 - n1, 0])
    cherry_street_direction = cherry_street_direction / np.linalg.norm(cherry_street_direction)

    print(f"Cherry Street axis direction (normalized ENU):")
    print(f"  East: {cherry_street_direction[0]:.4f}")
    print(f"  North: {cherry_street_direction[1]:.4f}")

    # Bobby Dodd is to the west, so we want to move in the direction that has
    # a negative (westward) east component
    # If the cherry street direction is pointing east, reverse it
    if cherry_street_direction[0] > 0:
        movement_direction = -cherry_street_direction
        print("\n  Reversing direction to point towards Bobby Dodd (west)")
    else:
        movement_direction = cherry_street_direction

    print(f"\nMovement direction towards Bobby Dodd:")
    print(f"  East: {movement_direction[0]:.4f}")
    print(f"  North: {movement_direction[1]:.4f}")
    print(f"  Distance: {MOVE_DISTANCE}m")

    # Calculate movement vector in meters
    movement_vector = movement_direction * MOVE_DISTANCE
    print(f"\nMovement vector (meters):")
    print(f"  ΔE = {movement_vector[0]:.4f}m")
    print(f"  ΔN = {movement_vector[1]:.4f}m")
    print(f"  ΔU = {movement_vector[2]:.4f}m")

else:
    print("WARNING: Could not find Facade 1 for Cherry Street axis calculation")
    print("Using default westward direction (towards Bobby Dodd)")
    movement_vector = np.array([-MOVE_DISTANCE, 0, 0])  # West

# Apply movement to Facade 2
print("\n" + "="*80)
print("APPLYING MOVEMENT TO FACADE 2")
print("="*80)

# Calculate overall center for conversions
all_coords = []
for feature in data['features']:
    coords = feature['geometry']['coordinates']
    if isinstance(coords, list) and len(coords) > 0:
        coord_array = coords[0] if isinstance(coords[0], list) else coords
        for c in coord_array:
            if isinstance(c, list) and len(c) == 3:
                all_coords.append(c)

center_lon = sum(c[0] for c in all_coords) / len(all_coords)
center_lat = sum(c[1] for c in all_coords) / len(all_coords)
center_alt = sum(c[2] for c in all_coords) / len(all_coords)

print(f"Building center: [{center_lon:.10f}, {center_lat:.10f}, {center_alt:.2f}]")

# Create modified data
modified_data = copy.deepcopy(data)

features_moved = 0
for idx in facade2_indices:
    feature = modified_data['features'][idx]
    coords = feature['geometry']['coordinates']

    if not isinstance(coords, list) or len(coords) == 0:
        continue

    coord_array = coords[0] if isinstance(coords[0], list) else coords
    new_coords = []

    for c in coord_array:
        if isinstance(c, list) and len(c) == 3:
            # Convert to ENU
            e = (c[0] - center_lon) * METERS_PER_DEGREE_LON
            n = (c[1] - center_lat) * METERS_PER_DEGREE_LAT
            u = c[2] - center_alt

            # Apply movement
            e += movement_vector[0]
            n += movement_vector[1]
            u += movement_vector[2]

            # Convert back to GPS
            new_lon = center_lon + (e / METERS_PER_DEGREE_LON)
            new_lat = center_lat + (n / METERS_PER_DEGREE_LAT)
            new_alt = center_alt + u

            new_coords.append([new_lon, new_lat, new_alt])
        else:
            new_coords.append(c)

    feature['geometry']['coordinates'] = [new_coords]

    # Update elevation_m
    if 'elevation_m' in feature['properties']:
        valid_coords = [c for c in new_coords if isinstance(c, list) and len(c) == 3]
        if valid_coords:
            avg_alt = sum(c[2] for c in valid_coords) / len(valid_coords)
            feature['properties']['elevation_m'] = avg_alt

    features_moved += 1

print(f"✓ Moved {features_moved} Facade 2 features by {MOVE_DISTANCE}m towards Bobby Dodd")

# Add metadata
modified_data['properties'] = modified_data.get('properties', {})
modified_data['properties']['modification'] = f"Facade 2 moved {MOVE_DISTANCE}m towards Bobby Dodd Way along Cherry Street axis"
modified_data['properties']['movement_vector_m'] = {
    'east': float(movement_vector[0]),
    'north': float(movement_vector[1]),
    'up': float(movement_vector[2])
}

# Save
output_file = f"{OUTPUT_FOLDER}/Complete_Facade2_Moved_{MOVE_DISTANCE}m_BobbyDodd.geojson"
with open(output_file, 'w') as f:
    json.dump(modified_data, f, indent=2)

file_size = len(json.dumps(modified_data)) / 1024

print("\n" + "="*80)
print("✓✓✓ FACADE 2 MOVED ✓✓✓")
print("="*80)
print(f"\nFile: {output_file} ({file_size:.1f} KB)")
print(f"\nModification:")
print(f"  ✓ Facade 2 moved {MOVE_DISTANCE}m towards Bobby Dodd Way")
print(f"  ✓ Movement along Cherry Street axis")
print(f"  ✓ Direction: {movement_vector[0]:.3f}m East, {movement_vector[1]:.3f}m North")
print(f"  ✓ All other components unchanged")
print(f"  ✓ Total features: {len(modified_data['features'])}")
print(f"\nUpload to ArcGIS Online to verify Facade 2 alignment!")
print("="*80)
